
## ws47-bt-threads
| build | n | wall ms | task-clock ms |
|---|---|---|---|
| fastpath | 5 | 1479 [1439-1632] | 2550 [2526-2722] |
| workerspin | 5 | 1479 [1430-1672] | 2564 [2516-2780] |

## ws47-idle
| build | n | idle-sleep cpu ms | wall ms | task-clock ms |
|---|---|---|---|---|
| fastpath | 5 | 0.00 [0.00-0.00] | 2081 [2080-2082] | 89 [89-91] |
| workerspin | 5 | 9.00 [7.00-11.00] | 2082 [2076-2085] | 98 [94-103] |

## ws47-spectral-4cpu
| build | n | compute ms | wall ms | task-clock ms |
|---|---|---|---|---|
| fastpath | 7 | 440 [421-459] | 510 [490-526] | 1183 [1171-1192] |
| workerspin | 7 | 317 [301-373] | 389 [370-445] | 1245 [1213-1289] |

## ws47-spectral-5cpu
| build | n | compute ms | wall ms | task-clock ms |
|---|---|---|---|---|
| fastpath | 7 | 290 [287-300] | 360 [358-369] | 1176 [1171-1180] |
| workerspin | 7 | 284 [282-317] | 353 [351-389] | 1203 [1196-1239] |

## ws47-spectral-all
| build | n | compute ms | wall ms | task-clock ms |
|---|---|---|---|---|
| fastpath | 7 | 300 [298-303] | 369 [366-371] | 1207 [1202-1218] |
| workerspin | 7 | 295 [292-299] | 363 [359-366] | 1244 [1230-1256] |

## ws47-stagger
| build | n | stagger total ms | pass span ms | wall ms | task-clock ms |
|---|---|---|---|---|---|
| fastpath | 5 | 356 [355-363] | 8.41 [8.31-8.54] | 428 [425-434] | 1321 [1316-1332] |
| workerspin | 5 | 378 [369-386] | 8.68 [8.63-8.99] | 447 [440-461] | 1425 [1404-1439] |

## ws47-stress-w4
| build | n | wall ms | task-clock ms |
|---|---|---|---|
| fastpath | 5 | 1239 [1199-1258] | 2981 [2763-3053] |
| workerspin | 5 | 1225 [1187-1229] | 2894 [2743-2992] |


## ws-bt-threads
| build | n | wall ms | task-clock ms |
|---|---|---|---|
| fastpath | 5 | 1638 [1480-1771] | 2715 [2531-2730] |
| workerspin | 5 | 1565 [1449-1757] | 2588 [2500-2766] |

## ws-idle
| build | n | idle-sleep cpu ms | wall ms | task-clock ms |
|---|---|---|---|---|
| fastpath | 5 | 0.00 [0.00-0.00] | 2082 [2079-2085] | 89 [86-91] |
| workerspin | 5 | 9.00 [9.00-11.00] | 2080 [2073-2085] | 96 [92-100] |

## ws-spectral-03
| build | n | compute ms | wall ms | task-clock ms |
|---|---|---|---|---|
| fastpath | 7 | 421 [391-461] | 493 [464-528] | 1197 [1192-1216] |
| workerspin | 7 | 314 [300-331] | 383 [370-405] | 1267 [1250-1302] |

## ws-spectral-04
| build | n | compute ms | wall ms | task-clock ms |
|---|---|---|---|---|
| fastpath | 7 | 318 [297-362] | 391 [368-434] | 1178 [1173-1196] |
| workerspin | 7 | 288 [284-322] | 362 [357-392] | 1221 [1209-1289] |

## ws-spectral-all
| build | n | compute ms | wall ms | task-clock ms |
|---|---|---|---|---|
| fastpath | 7 | 300 [296-308] | 373 [367-379] | 1218 [1209-1236] |
| workerspin | 7 | 293 [291-323] | 366 [361-411] | 1241 [1235-1318] |

## ws-stagger
| build | n | stagger total ms | pass span ms | wall ms | task-clock ms |
|---|---|---|---|---|---|
| fastpath | 5 | 357 [347-479] | 8.41 [8.30-11.27] | 423 [419-548] | 1289 [1279-1307] |
| workerspin | 5 | 523 [362-532] | 13 [9-13] | 594 [426-602] | 1468 [1370-1498] |

## ws-stress-w4
| build | n | wall ms | task-clock ms |
|---|---|---|---|
| fastpath | 5 | 1224 [988-1244] | 2812 [1883-3057] |
| workerspin | 5 | 1116 [1017-1242] | 2323 [1973-3168] |

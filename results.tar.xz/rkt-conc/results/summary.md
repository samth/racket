
## bt-par
| build | n | wall ms | task-clock ms |
|---|---|---|---|
| master | 5 | 1502 [1427-1577] | 2712 [2611-2774] |
| fastpath | 5 | 1716 [1448-1811] | 2903 [2674-3015] |
| spin | 5 | 1440 [1408-1487] | 2652 [2616-2708] |

## bt-threads
| build | n | wall ms | task-clock ms |
|---|---|---|---|
| master | 5 | 1812 [1775-1985] | 2982 [2947-3147] |
| fastpath | 5 | 1377 [1324-1516] | 2431 [2379-2612] |
| spin | 5 | 1393 [1303-1729] | 2457 [2357-2797] |

## hash-par
| build | n | ref ms | set! ms | instr (M) | wall ms | task-clock ms |
|---|---|---|---|---|---|---|
| master | 5 | 229 [227-230] | 233 [231-233] | 7446 [7445-7446] | 526 [519-528] | 524 [517-527] |
| fastpath | 5 | 229 [229-231] | 235 [235-237] | 8387 [8386-8387] | 532 [528-533] | 530 [526-530] |
| spin | 5 | 142 [142-143] | 156 [156-157] | 8586 [8586-8587] | 364 [358-365] | 362 [356-363] |

## hash-seq
| build | n | ref ms | set! ms | instr (M) | wall ms | task-clock ms |
|---|---|---|---|---|---|---|
| master | 5 | 229 [227-229] | 232 [231-233] | 7445 [7445-7445] | 527 [523-529] | 525 [521-525] |
| fastpath | 5 | 60 [59-60] | 98 [97-99] | 6863 [6863-6864] | 222 [221-229] | 220 [218-227] |
| spin | 5 | 60 [59-60] | 98 [97-98] | 6863 [6863-6863] | 223 [218-224] | 220 [215-222] |

## spectral-03
| build | n | compute ms | wall ms | task-clock ms |
|---|---|---|---|---|
| master | 5 | 396 [370-430] | 455 [432-491] | 1178 [1172-1184] |
| fastpath | 5 | 403 [396-414] | 466 [455-483] | 1174 [1170-1181] |
| spin | 5 | 403 [400-413] | 470 [459-477] | 1170 [1169-1176] |

## spectral-04
| build | n | compute ms | wall ms | task-clock ms |
|---|---|---|---|---|
| master | 5 | 294 [288-301] | 355 [351-360] | 1167 [1166-1171] |
| fastpath | 5 | 290 [289-333] | 352 [350-399] | 1168 [1164-1173] |
| spin | 5 | 287 [283-327] | 350 [346-394] | 1166 [1163-1180] |

## stress-w12
| build | n | wall ms | task-clock ms |
|---|---|---|---|
| master | 5 | 4287 [4111-4309] | 12604 [12098-13240] |
| fastpath | 5 | 3714 [3702-3916] | 11540 [10993-11889] |
| spin | 5 | 3627 [3360-4237] | 10491 [9836-13189] |

## stress-w4
| build | n | wall ms | task-clock ms |
|---|---|---|---|
| master | 5 | 1242 [1182-1331] | 3106 [2840-3289] |
| fastpath | 5 | 1206 [933-1290] | 2863 [1645-3251] |
| spin | 5 | 446 [429-449] | 593 [577-622] |

## bt-par rerun (7 interleaved, wall ms)
master: 1400 1489 1355 1480 1373 1430 1417 
fastpath: 1375 1637 1484 1489 1649 1463 1590 
spin: 1397 1521 1468 1476 1472 1462 1400 

## GC counts (-W debug@GC, taskset 0-3)
gc/bt-par-fastpath-1.txt: major 5; minor 389; 1021ms
gc/bt-par-fastpath-2.txt: major 5; minor 393; 1058ms
gc/bt-par-master-1.txt: major 5; minor 389; 1010ms
gc/bt-par-master-2.txt: major 5; minor 389; 991ms
gc/bt-par-spin-1.txt: major 4; minor 389; 993ms
gc/bt-par-spin-2.txt: major 5; minor 397; 1015ms
gc/bt-threads-fastpath-1.txt: major 4; minor 380; 958ms
gc/bt-threads-fastpath-2.txt: major 2; minor 387; 773ms
gc/bt-threads-master-1.txt: major 4; minor 1167; 1464ms
gc/bt-threads-master-2.txt: major 3; minor 1168; 1460ms
gc/bt-threads-spin-1.txt: major 4; minor 386; 892ms
gc/bt-threads-spin-2.txt: major 4; minor 386; 891ms
